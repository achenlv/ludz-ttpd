<?php

echo "viens uzdevums"

?>
